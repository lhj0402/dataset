# ZeroDivisonError

tup1 = ('Google', 'Runoob', 1997, 2000)
tup2 = (1, 2, 3, 4, 5, 6, 7)

print("tup1[2]: ", tup1[2]/0)# ZeroDivisonError
print("tup2[1:5]: ", tup2[1:5])

