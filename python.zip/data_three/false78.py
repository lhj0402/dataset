# TypeError
list1 = [1, 2, 3]
tup1 = 1, 2, 3
var1 = list1 + tup1  # TypeError
print(var1)