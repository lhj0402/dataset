# ZeroDivisonError

list = [99,88,77,66,55,44]
print( list[0] )
print( list[1] )
print( list[2]/0)# ZeroDivisonError


