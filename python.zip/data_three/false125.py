# IndexError
list1 = ['Google', 'baidu', 1997, 2000]
for i in range(0, 13):
    list1.pop()  # IndexError
