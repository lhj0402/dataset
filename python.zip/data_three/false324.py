#IndexError
list1 = [1,2,3,4,5]
list2 = list1
var1 = len(list2)
for var2 in range(var1):
    print(list2[var2])
list1.pop()
for var2 in range(var1):
    print(list2[var2])      #IndexError