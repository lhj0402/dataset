#ZeroDivisionError
list1=list(map(float,input().split()))
var1=sum(list1)//(len(list1)-len(list1))#ZeroDivisionError
print('%.5f'%(var1))
#https://www.luogu.com.cn/problem/P2393?contestId=143