# IndexError
list1 = ['Google', 'baidu', 1997, 2000]
list1.clear()
list1.pop()  # IndexError
