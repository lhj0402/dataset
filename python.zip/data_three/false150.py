# ZeroDivisionError
list1 = [786, 2.23, 'john', 70.2]
str1 = 'heool'
var1 = 192
if str1 == 'hello':
    var1 = var1 * 2
else:
    var1 = 1002 - 1002
print(list1[3] + 3)
print(list1[1] / var1)  # ZeroDivisionError
