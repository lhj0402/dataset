#IndexError
list1 = [1,2,3,4,5]
print(list1[len(list1)])    #IndexError