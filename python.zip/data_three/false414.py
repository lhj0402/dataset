#IndexError
str1=input()
x=int(str1)
if x>=0 and x<=100:
    print(str1[3])#IndexError
if x<=1:
    print('Today, I ate %d apple.'%(x))
else:
    print('Today, I ate %d apples.'%(x))