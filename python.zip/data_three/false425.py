#TypeError
list1=list(map(int,input().split()))
list1.sort()
str1=''
for var1 in list1:
    str1=str+str(var1)+' '#TypeError
print(str1[:len(str1)-1])
#https://www.luogu.com.cn/problem/P5715?contestId=24871