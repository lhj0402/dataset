#ZeroDivisionError
var1 = 3
var2 = 6
var3 = 1
while var3 <= 3:
    var2 = var2 % var1 #ZeroDivisionError
    var1 = var2 
    var3 += 1
