# TypeError
word = 'Python'
print(word[0], word[6])# TypeError

