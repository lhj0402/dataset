# TypeError
str1 = 'upc'
print(str1[1])
var1 = 1/1.0
if var1<len(str1) and var1>=-len(str1):
    print(str1[var1])# TypeError