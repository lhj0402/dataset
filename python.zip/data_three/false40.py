# ZeroDivisionError
list1 = [1,2,3,4,5,6,7]
list2 = [1,2,3,4]
list2.clear()
var1 = sum(list1) / len(list2)  # ZeroDivisionError