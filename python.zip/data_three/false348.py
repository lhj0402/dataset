#TypeError
list1 = [[1,2,3],[4,5,6],[7,8,9]]
var1 = list1[0]+2   #TypeError
print(list1[0])