#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #TypeError
a = ['one', 'two', 'three']
for i in a[:]:
    print (a[i]) #TypeError

