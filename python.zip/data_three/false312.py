#TypeError
var1 = 'abc'
var2=abs(var1)  #TypeError
print(var2)