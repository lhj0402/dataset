var1 = 1209
var2 = 'fwojfw'
if var1 > 31:
    print(var1)
else:
    print("fowjf")
