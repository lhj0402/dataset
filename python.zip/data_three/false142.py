# ZeroDivisionError
import numpy as np

list1 = [1.2, 8, 4]
np1 = np.array(list1)
var1 = 320 / (int(np1.ndim) - 1)  # ZeroDivisionError
