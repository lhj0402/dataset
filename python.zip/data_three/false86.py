# TypeError
list1 = [[1, 2, 3], [4, 5]]
list2 = [[1, 2, 3, 4], [5, 6]]
list1[1][0] += list2[1]  # TypeError

