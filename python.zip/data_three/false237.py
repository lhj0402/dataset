# TypeError

list = [ 'abcd', 786 , 2.23, 'runoob', 70.2 ]
tinylist = [123, 'runoob']

print (list)
print (list[1]+'9')        # TypeError
print (list[1:3])
print (list[2:])
print (tinylist * 2)
