#!/usr/bin/python
# -*- coding: UTF-8 -*-
#ZeroDivisionError
m=66
for i in range(5):
    m/=i  #ZeroDivisionError
    print(m)
