#TypeError
var1=input()
var2=input()
print(var1*var2)#TypeError
#https://www.luogu.com.cn/problem/P1303