#ZeroDivisionError
list = [1, 2, 3, 5, 6]
var1 = list.count(0)
print(6 % var1) #ZeroDivisionError
