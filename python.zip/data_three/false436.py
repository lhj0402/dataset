#ZeroDivisionError
var1=int(input())
var2=0
while var2*(var2+1)//2<=var1:
    var2+=1
var2-=1
var3=var2*(var2+1)*(2*var2+1)//6+(var1-var2*(var2+1)//0)*(var2+1)#ZeroDivisionError
print(var3)
#https://www.luogu.com.cn/problem/P2669?contestId=303