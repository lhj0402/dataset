#ZeroDivisionError
height,weight=0,68
bmi=weight/(height**2)  #ZeroDivisionError
if bmi<18.5:
    local, wto = "偏瘦", "偏瘦"
elif 18.5<=bmi<24:
    local, wto = "正常", "正常"
elif 24<=bmi<25:
    local, wto = "偏胖", "正常"
elif 25<=bmi<28:
    local, wto = "偏胖", "偏胖"
elif 28<=bmi<30:
    local, wto = "肥胖", "偏胖"
else:
    local, wto = "肥胖", "肥胖"
print("BMI指标为国际：{:}，国内：{:}".format(wto,local))