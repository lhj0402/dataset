#IndexError


list = ['red', 'green', 'blue', 'yellow', 'white', 'black']

print( list[-7] )#IndexError