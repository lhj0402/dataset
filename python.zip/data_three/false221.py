#IndexError
var1 = 'Hello'
var2 = "Runoob"

print("var1[0]: ", var2[-7])#IndexError