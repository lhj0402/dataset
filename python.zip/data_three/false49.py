# TypeError
str1 = "Hello,%d"
val1 = (2021)
print(str1%val1)
str2 = "Hello,%d"
val2 = ('2021')
print(str2%val2)# TypeError