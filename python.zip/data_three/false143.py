# TypeError
import numpy as np

np1 = np.zeros('str')  # TypeError
