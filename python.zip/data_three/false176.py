#IndexError
list = [0, 1, 2, 3, 4, 5, 6]
var1 = 0
var2 = 1
while var2 <= 6:
    var1 += var2
    var2 += 1
print(list[var2]) #IndexError
