#ZeroDivisionError
list = list(range(5))
print(list[4] / list[0]) #ZeroDivisionError
