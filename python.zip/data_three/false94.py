# TypeError
list1 = [1, 2, 3]
tuple1 = [4, 25, 6]
var1 = list1 - tuple1  # TypeError
print(var1)