# TypeError
var1 = "hello world"
var2 = var1 + 1  # TypeError
print(var2)
