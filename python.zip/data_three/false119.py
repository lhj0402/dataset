# TypeError
a = 2
b = 10
c = 0

if a == b:
    print("1 - a 等于 b")
else:
    print('str' + 2)  # TypeError
