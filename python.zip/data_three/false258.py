#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #TypeError
if __name__ == '__main__':
    str1 = "helloworld2008"
    str2 = 2008
    ncount = str1.count(str2)  #TypeError
    print(ncount)

