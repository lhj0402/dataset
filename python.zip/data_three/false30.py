# IndexError
list1 = range(5)
list2 = [i + 1 for i in list1]
var1 = len(list2)-list2[4]
var2 = sum(list2)
print(var2/var1)# IndexError