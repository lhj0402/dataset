#TypeError
list1 = [1,2,3,4,5]
list1 = list1+1 #TypeError