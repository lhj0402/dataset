#TypeError
var = 'helloworld'
print(var[ord(max(var)) % ord(min(var) // 2)]) #TypeError
