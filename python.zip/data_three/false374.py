# TypeError
var1 = (2.23, 'john', 70.2)
var1[2] = 1000  # TypeError
