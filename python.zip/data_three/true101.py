var1 = "hello world"
print(var1 + '1')
