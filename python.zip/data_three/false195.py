#TypeError
import cmath
var1 = -1
var2 = cmath.sqrt(var1)
var3 = 'hello world'
print(var3[var2]) #TypeError
