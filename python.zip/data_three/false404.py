# IndexError
var1 = (786, 2.23, 'john', 70.2)
print(var1[31])  # IndexError
