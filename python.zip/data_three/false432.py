#ZeroDivisionError
var1=int(input())
var2=0
for var3 in range(var1):
    var2+=int(input())
if var2%0==1:#ZeroDivisionError
    print('Alice')
else:
    print('Bob')
#https://www.luogu.com.cn/problem/P4702?contestId=7000