#ZeroDivisionError
var1 = 0x3b
var2 = 0o73
var3 = var1 - var2
print(6 % var3) #ZeroDivisionError
