#IndexError
list1 = []
print(list1[0]) #IndexError