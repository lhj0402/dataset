#ZeroDivisionError
list = [1, 2, 2, 3, 0]
var = list.pop();
print(3 / var) #ZeroDivisionError
