# IndexError
list1 = [1, 2]
list2 = [3, 4, 5, 6, 7]
list1.append(list2)
var1 = list1[3]  # IndexError
print(var1)