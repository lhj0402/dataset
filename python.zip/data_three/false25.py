# IndexError
import numpy as np
numpy1 = np.arange(10)
print(numpy1[10])  # IndexError