dict1 = {
    'sunshine': {
        'name': 'jsw',
        'age': 22
    },
    'garlic': {
        'name': 'lcw',
        'age': 21
    }
}
for var1, var2 in dict1.items():
    print(var1 + ":")
    for var3, var4 in var2.items():
        print("\t" + var3 + ": " + str(var4))