#TypeError
str1=input()
#str1=str1[0:1]
print(chr(ord(str1)-32))#TypeError
#https://www.luogu.com.cn/problem/P5704?contestId=25415