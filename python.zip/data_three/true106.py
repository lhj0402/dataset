tuple1 = (2.23, 'john', 70.2, 323)
print(tuple1[1:3])
