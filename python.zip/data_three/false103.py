# ZeroDivisionError
var1 = 20
var2 = 100 - 100
print(var1 / var2)  # ZeroDivisionError
