#ZeroDivisionError
list1=list(map(int,input().split()))
var1=pow(2,len(list1)-1)
var2=sum(list1)*var1//((-1)-(-1))#ZeroDivisionError
print(var2)
#https://www.luogu.com.cn/problem/P2415?contestId=199