# IndexError
str1 = "abcdefgh"
var1 = str1[20]  # IndexError
print(var1)