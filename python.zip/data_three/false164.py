#IndexError
list = [1, 2, 3]
var1 = 0
while var1 <= 4:
    print(list[var1])
    var1 += 1 #IndexError
