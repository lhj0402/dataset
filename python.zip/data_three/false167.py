#ZeroDivisionError
var1 = 1
var2 = 5
while var1 <= 5:
    var3 = var2 % 5
    var4 = var2 / 5
    var2 = var3 * var4
    var1 += 1
print(10 % var2) #ZeroDivisionError
