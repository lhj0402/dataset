print("My name is %s and weight is %d kg!" % ('Zara', 21))
