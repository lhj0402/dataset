set1 = set('lcadfswwwwww')
set2 = frozenset(set1)
print(set2)
