#ZeroDivisionError
list = [1, 2, 2, 3, 4]
var = list.count(0);
print(3 / var) #ZeroDivisionError
