# IndexError
list1=[]
print(list1[5]) # IndexError