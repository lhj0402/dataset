# IndexError
list1 = ['Google']
del list1[2]  # IndexError
