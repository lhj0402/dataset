#TypeError
li = ['alex', 'wusir', 'eric', 'rain', 'alex']
li.insert("0", 'seven')  #TypeError
print(li)