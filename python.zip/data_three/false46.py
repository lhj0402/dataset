# ZeroDivisionError
var1 = 1
var2 =2021
if var1 %2 !=0:
    print(var2/(var1>>1))# ZeroDivisionError