#ZeroDivisionError
var1,var2,var3,var4=map(int,input().split(' '))
if var3==0:
    if var4!=var1:
        print('NO')
    else:
        print('YES')
        for var5 in range(1,var1+1):
            print('0 '+str(var2))
else:
    var6=var3//var4
    var8=var3+var1-var4
    var9=0/var1
    var7=(var8-1)//var9+1#ZeroDivisionError
    var6=min(var6,var2)
    var7=max(var7,1)
    if var7>var6:
        print('NO')
    else:
        print('YES')
        for var10 in range(1,var4+1):
            print(str(var6)+' '+str(var2-var6))
            var3-=var6
        for var11 in range(var4+1,var1+1):
            if var3>=var6-1:
                print(str(var6-1)+' '+str(var2-var6+1))
                var3=var3-var6+1
            else:
                print(str(var3)+" "+str(var2-var3))
                var3=0