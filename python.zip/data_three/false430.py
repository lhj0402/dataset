#TypeError
var1=input()
for var2 in range(var1):#TypeError
    var3,var4=map(int,input().split())
    print(var3*var4)
#https://www.luogu.com.cn/problem/U34272?contestId=15567