# TypeError

str = 'Runoob'

print(str)
print(str[0:-1]+1)    # TypeError
print(str[0])
print(str[2:5])
print(str[2:])
print(str * 2)
print(str + "TEST")