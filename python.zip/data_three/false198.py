#ZeroDivisionError
var1 = (246, 'house')
var2 = list(var1)[0] % 123 
print(1 // var2) #ZeroDivisionError
