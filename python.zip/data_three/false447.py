#ZeroDivisionError
var1,var2=map(int,input().split())
var3,var4,var5=0,0,0
for var6 in range(1,var1+1):
    if var6%var2==0:
        var3+=var6
        var5+=1
    else:
        var4+=var6
print('%.1f %.1f'%(var3/var5,var4/(var1-var1)))#ZeroDivisionError
#https://www.luogu.com.cn/problem/P5719