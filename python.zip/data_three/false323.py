#TypeError
var1 = 'abc'
var2 = 1
if var1>var2:   #TypeError
    print(var2)
else:
    print(var1)