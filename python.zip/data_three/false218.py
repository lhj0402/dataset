#IndexError

var1 = 'Hello'
var2 = "Runoob"

print("var1[0]: ", var1[-10])#IndexError