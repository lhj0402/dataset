# TypeError
var1 = 1
var2 = var1 + '1' # TypeError
print(var2)