var1 = 10
var2 = 30
print(var1 + 1)
