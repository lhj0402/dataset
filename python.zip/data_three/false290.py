#ZeroDivisionError
var1=59
for i in range(5):
    var1/=i #ZeroDivisionError