#ZeroDivisionError
var1,var2=map(int,input().split())
var2=0
var3=var1**(1/var2)#ZeroDivisionError
print(int(var3))
#https://www.luogu.com.cn/problem/P6685?contestId=31672