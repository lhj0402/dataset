#ZeroDivisionError
str1=input()
var2=0/0#ZeroDivisionError
for var1 in range(97,123):
    var2=max(var2,str1.count(chr(var1)))
print(var2)