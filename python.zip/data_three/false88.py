# TypeError
list1 = [1, 2, 3, 4, 5, 'a']
for var1 in range(6):
    list1[var1] += var1  # TypeError
print(list1)