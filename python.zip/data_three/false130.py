# TypeError
basket = {'apple', 'orange', 'apple', 'pear', 'orange', 'banana'}
for i in range(0, 20):
    basket.pop('apple')  # TypeError
