#  ZeroDivisionError
str1 = ''
str2 = 'jsw'
var1 = len(str1)
var2 = len(str2)
var3 = var2 / var1  # ZeroDivisionError
var3 += 1
print(var3)