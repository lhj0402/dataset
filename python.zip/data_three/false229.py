# TypeError
word = 'Python'
print(word[0], word[5])
print(word[-1], word[-6]+1)# TypeError
