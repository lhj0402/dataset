#IndexError

list = ['Google', 'Runoob', "Zhihu", "Taobao", "Wiki"]

print(list[-7])#IndexError
