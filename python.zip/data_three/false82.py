# TypeError
list1 = [1, 2, 3, 'a']
var1 = 10
for var2 in range(len(list1)):
    list1[var2] += var1  # TypeError
