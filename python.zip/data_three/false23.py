# TypeError
list1 = ['a','b','c']
list1[0] = 'A'
print(list1)
tup1 = 'a','b','c'
tup1[0] = 'A' # TypeError
print(tup1)

