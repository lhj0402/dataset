var1 = 1
if var1 == 1:
    print("heool")