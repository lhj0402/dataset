#  ZeroDivisionError
var1 = 0
while var1 != -10:
    var2 = 10 / var1  # ZeroDivisionError
    var1 -= 1
    print(var1)
    print(var2)