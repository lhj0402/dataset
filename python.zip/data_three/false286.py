#IndexError
li = ['alex', 'wusir', 'eric', 'rain', 'alex']

#del
#1.通过索引删除元素
del li[100]  #IndexError
print(li)