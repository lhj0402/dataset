#TypeError
var1=input()
var2=int(input())
print(var1+var2)#TypeError
#https://www.luogu.com.cn/problem/P1601