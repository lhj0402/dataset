#IndexError
str1,str2=input().split()
var1=int(str2)
len1,len2=0,int(len(str1))
for var2 in range(97,123):
    len1=max(len1,str1.count(chr(var2)))
for var3 in range(65,91):
    len1=max(len1,str1.count(chr(var3)))
for var4 in range(0,10):
    len1=max(len1,str1.count(str(var4)))
var5=0
while len2<var1:
    var5+=1
    len2+=len1
    len1*=2
print(var5)
print(str1[len2])#IndexError