# TypeError
list1 = [1, 2, 3, 4, 5, 6, 7]
list1.clear()
var1 = 20 / list1.count()  # TypeError
