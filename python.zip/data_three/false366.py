# IndexError
list1=[1,2,3,4]
print(list1[5]) # IndexError