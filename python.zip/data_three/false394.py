# ZeroDivisionError
var1 = 10
var2 = 2.3
var3 = var1 // var2
var4 = var3 // (var2 - 2.3)  # ZeroDivisionError