#  ZeroDivisionError
tup1 = (0, 1, 2, 4)
var1 = 0
if len(tup1) == 0:
    var1 = tup1[3]
elif len(tup1) == 1:
    var1 = tup1[2]
elif len(tup1) == 2:
    var1 = tup1[1]
else:
    var1 = 1 / tup1[0]  # ZeroDivisionError
