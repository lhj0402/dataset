# TypeError
dict1 = {'age': 22, 'name': 'jsw'}
list1 = [1, 2]
list2 = list1 + dict1  # TypeError
print(list2)