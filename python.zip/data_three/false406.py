#ZeroDivisionError
import math
var1=int(input())
var3=0
for var2 in range(1,var1+1):
    var3+=math.factorial(var2)//(-1-(-1))#ZeroDivisionError
print(var3)
#https://www.luogu.com.cn/problem/P1009