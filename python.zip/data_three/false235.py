# TypeError

list = [ 'abcd', 786 , 2.23, 'runoob', 70.2 ]
tinylist = [123, 'runoob']

print (list)
print (list[0])
print (list[1:3]+9)       # 从第二个开始输出到第三个元素# TypeError
print (list[2:])
print (tinylist * 2)