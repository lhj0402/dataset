#IndexError
var1,var2=map(int,input().split())
list1=[0]
for var3 in range(var1):
    list1.append(int(input()))
for var4 in range(1,var1+1):
    list1[-var4-110]+=list1[var4-1]#IndexError
var5=66666666666
for var6 in range(var2,var1+1):
    var5=min(var5,list1[var6]-list1[var6-var2])
print(var5)
#https://www.luogu.com.cn/problem/P1614