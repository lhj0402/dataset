# IndexError
str1 = '0,1,2,3'
list1 = str1.split(',')
list2 = [0, 1, 2]
for var1 in list1:
    var2 = int(var1)
    var3 = list2[var2]  # IndexError
