# TypeError
set1 = set('lcadfswwwwww')
print(set1[4])  # TypeError
