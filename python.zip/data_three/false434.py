#TypeError
var1,var2=map(int,input().split())
list1=list(map(input().split()))#TypeError
var3=0
for var4 in range(1,var1):
    if list1[var4]+list1[var4-1]<=var2:
        continue;
    var5=(list1[var4]+list1[var4-1])-var2
    var3+=var5
    if list1[var4-1]<=var2:
        list1[var4]-=var5
    else:
        list1[var4]=0
        list1[var4-1]=var2
print(var3)
#https://www.luogu.com.cn/problem/P3817?contestId=2437