#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #TypeError
def hello_runoob(i):
    print (i+'RUNOOB') #TypeError
 
def hello_runoobs():
    for i in range(3):
        hello_runoob(i)
if __name__ == '__main__':
    hello_runoobs()
