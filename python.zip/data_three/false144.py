# TypeError
list1 = [1, 2, 3, 4, 5, 6, 6]
list2 = [2, 3, 4, 5, 6]
list1.append(list2 + 1)  # TypeError
