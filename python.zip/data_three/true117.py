set1 = set("heolollew")
set1.add('w')
print(set1)
