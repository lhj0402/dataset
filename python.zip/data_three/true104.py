tuple1 = (786, 2.23, 'john', 70.2)
print(tuple1[2])
