#  ZeroDivisionError
import math
var1 = 0.00023
var2 = math.floor(var1)
var3 = 0.000021
var4 = var3 / var2  # ZeroDivisionError
