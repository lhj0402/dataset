#IndexError
list1 = [1,2,3,4,5]
list2 = list1
var1 = len(list1)
for var2 in range(var1):
    list1.pop(-1)
for var2 in range(var1):
    list2.pop(-1)     #IndexError