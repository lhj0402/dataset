#TypeError
list1 = [[1,2,3],[4,5,6],[7,8,9]]
for var1 in len(list1[0]):  #TypeError
    var2 = list1[1][var1]+2
    print(var2)