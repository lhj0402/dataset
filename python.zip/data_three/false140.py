# IndexError
import numpy as np

numpy1 = np.arange(10)
print(numpy1[34])  # IndexError
