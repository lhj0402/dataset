# ZeroDivisonError

counter = 100  # 赋值整型变量
miles = 1000.0  # 浮点型
name = "John"  # 字符串

print(counter)
print(miles/0)# ZeroDivisonError
print(name)
