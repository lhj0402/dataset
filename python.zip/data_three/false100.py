#  ZeroDivisionError
list1 = [var1 - 1 for var1 in range(5)]
print(list1)
for var2 in list1:
    var3 = (var2 + 1) / var2  # ZeroDivisionError
    print(var3)
