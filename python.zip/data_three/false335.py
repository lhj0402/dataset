#IndexError
list1 = [1,2,3,4,5]
list2 = list1
for var1 in range(len(list1)):
    list1.pop(-1)
list3 = list2*2
print(list3[0])     #IndexError