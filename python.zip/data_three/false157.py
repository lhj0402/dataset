#ZeroDivisionError
var1 = "print(6 % 0)"
eval(var1) #ZeroDivisionError
