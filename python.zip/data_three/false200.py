#IndexError
var1 = 2
var2 = var1 << 3
var2 = ~var2
list = list(range(var1))
print(list[var2]) #IndexError
