# ZeroDivisionError
print(5 / 0)  # ZeroDivisionError
