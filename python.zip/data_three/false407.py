#IndexError
var1=int(input())
var4=0
var2=1
for var3 in range(1,var1+1):
    var2*=var3
    list1=[6,9]
    list1[233]=911#IndexError
    var4+=var2
print(var4)
#https://www.luogu.com.cn/problem/P1009