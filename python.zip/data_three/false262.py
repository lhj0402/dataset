#TypeError
s = ["man","woman","girl","boy","sister"]
for i in range(len(s)):
    s[i]+=i #TypeError