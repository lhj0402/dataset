#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #ZeroDivisionError
a = 2.0
b = 0
s = 0
for n in range(1,21):
    s += a / b  #ZeroDivisionError
    t = a
    a = a + b
    b = t
print (s)
