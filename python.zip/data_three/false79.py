# TypeError
list1 = [1, 2, 3]
list2 = ['a', 'b', 'c']
var1 = list1[1] + list2[1]  # TypeError
print(var1)