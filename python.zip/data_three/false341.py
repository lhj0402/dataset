#ZeroDivisionError
list1 = [1,2,3,4,5]
var1 = 0
for var2 in range(len(list1)):
    var1 = list1[0]+var1
    del list1[0]
print(var1/len(list1))  #ZeroDivisionError