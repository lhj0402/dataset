#IndexError
list = [1, 2, 2, 3, 4]
var = list.pop();
print(list[4]) #IndexError
