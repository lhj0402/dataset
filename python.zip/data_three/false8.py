# TypeError
var1 = complex(real=2, imag=2)
var2 = complex(real=1, imag=1)
print(var1 > var2)  # TypeError