#IndexError
var = 'Python'
print(var[0: -1])
print(var[6]) #IndexError
