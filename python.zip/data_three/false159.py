#IndexError
list = ['a', 'b']
list.pop()
list.pop()
print(list[0]) #IndexError
