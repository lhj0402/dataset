#TypeError
list1=[5,6,3,8,2]
var1=3
list1/=var1 #TypeError