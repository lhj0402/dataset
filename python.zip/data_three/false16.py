# IndexError
list1 = ['u','p','c','2','0','2','1']
var1 = list1.index('2')
str1 = 'hello'
while var1 < 7:
    var1 +=1
    str1 += list1[var1]# IndexError
print(str1)