# IndexError
tup1 = 1,2,3,4,5
for var in tup1:
    print(tup1[var])# IndexError
