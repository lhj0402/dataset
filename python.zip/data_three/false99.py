#  ZeroDivisionError
tup1 = ('physics', 'chemistry', 1997, 2000)
tup2 = (1, 2, 3, 4, 5, 0)
tup3 = "a", "b", "c"
var1 = tup2[len(tup2) - 1]
var2 = tup1[len(tup1) - 1]
var3 = var2 / var1  # ZeroDivisionError
print(var3)