# IndexError
list1 = ['p', 'c']
list2 = ['u']
list2.append(list1)
print(list2[2])  # IndexError