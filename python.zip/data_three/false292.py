#ZeroDivisionError
list1=[5,6,3,8,2]
var1=100
for i in list1[:]:
    i=var1/(i-3) #ZeroDivisionError