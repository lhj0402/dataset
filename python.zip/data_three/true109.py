set1 = set('runoob')
print(set1)
