# IndexError
list1 = [1, 2, 3, 4, 5, 6, 6]
list2 = [2, 3, 4, 5, 6]
list1.append(list2)
print(list2[5])  # IndexError
