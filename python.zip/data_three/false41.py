# ZeroDivisionError
import math
str1 = '64.5'
var1 = float(str1)
var2 = math.ceil(var1)
print(ord('Z')/(ord('A')-var2))# ZeroDivisionError