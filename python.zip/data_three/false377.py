# IndexError
var1 = "China"
str_sp = var1[23] # IndexError