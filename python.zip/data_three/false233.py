# TypeError

list = ['abcd', 786 , 2.23, 'runoob', 70.2 ]
tinylist = [123, 'runoob'+8]# TypeError

print(list)
print(list[0])
print(list[1:3])
print(list[2:])
print(tinylist * 2)
print(list + tinylist)