var1 = 10
var2 = 231
print(var1 + var2)
