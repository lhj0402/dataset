#  ZeroDivisionError
list1 = []
list2 = [1, 2, 3]
var1 = len(list1)
var2 = len(list2)
var3 = var2 / var1  # ZeroDivisionError


