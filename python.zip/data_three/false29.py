# ZeroDivisionError
import numpy as np
list1 = [1.23, 4.52, 3.88,6.31]
array1 = np.array(list1)
var1 = 110 / (array1.ndim - 1)  # ZeroDivisionError