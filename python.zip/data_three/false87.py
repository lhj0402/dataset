# TypeError
str1 = 'jsw'
str2 = str1 * 10
str3 = str1 * 'a'  # TypeError
print(str3)
