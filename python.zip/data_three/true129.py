list1 = [12, 213, 3]
if list1[1] == 213:
    print('list1[1] = 213')
