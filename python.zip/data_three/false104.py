# IndexError
list1 = [786, 2.23, 'john', 70.2]
print(list1[-10])  # IndexError
