# TypeError
var1 = complex(real=1, imag=9)
var2 = complex(real=17, imag=9)
print(var1 > var2)  # TypeError
