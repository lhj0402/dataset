#typeerror
import json
list1 = {'name': 'localhost', 'url': '127.0.0.1'}
list2 = ['name', 'localhost', 'url', '127.0.0.1']
var = json.dumps(list1)
print(list2[var]) #typeerror
