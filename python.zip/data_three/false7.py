# TypeError
import random
list1 = []
for var in range(10):
    list1.append(random.randint(0,10))
print(list1)
var1 = min(list1)
list2 = [2,3]
print(list2+var1)# TypeError