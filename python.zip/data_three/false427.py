#IndexError
var1=int(input())
for var2 in range(1,var1+1):
    arr1=list(map(int,input().split()))
    arr1=arr1[0:4]
    arr1.sort()
    if (arr1[0]+arr1[3]) != (arr1[1]+arr1[2]):
        print(0)
    else:
        if arr1[0]==arr1[4]:#IndexError
            print(1)
        elif arr1[0]==arr1[1]:
            print(4)
        else:
            print(8)