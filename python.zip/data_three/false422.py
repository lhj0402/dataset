#ZeroDivisionError
var1=int(input())
var1=(var1+1)*var1/0#ZeroDivisionError
print(var1)
#https://www.luogu.com.cn/problem/P5722?contestId=25415