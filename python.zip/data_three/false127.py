# TypeError
tuple1 = "a", "b", "c", "d"
del tuple1[2]  # TypeError
