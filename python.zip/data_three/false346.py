#ZeroDivisionError
var1 = 10
var2 = 0
list1 = [0]*10
for var in range(var1):
    var1 = var1-1
    var2 = var2+1
    var3 = var1+var2
    var4 = var1-var2
    if var3<var4:
        list1.append(var3*var4)
    else:
        list1.append(var3/var4) #ZeroDivisionError
print(list1)