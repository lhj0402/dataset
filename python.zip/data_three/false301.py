#TypeError
var1 = ['cat','dog','mouse']
for var2 in range(var1):    #TypeError
    print(var1[var2])