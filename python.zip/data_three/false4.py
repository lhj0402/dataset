# TypeError
list1 = [1, 2, 3, 4]
list1.insert(0,'0')
for var in list1:
    if var%2 == 0:# TypeError
        print(var,'is a even')