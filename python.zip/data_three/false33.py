# ZeroDivisionError
var1 = 0
var2 = 2021
var3 = var1 & var2
var4 = 2020 / var3  # ZeroDivisionError