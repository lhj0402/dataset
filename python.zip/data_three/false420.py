#ZeroDivisionError
var1=int(input())
if var1%100==0:
    if var1%0==0:#ZeroDivisionError
        print(1)
    else:
        print(0)
else:
    if var1%4==0:
        print(1)
    else:
        print(0)
#https://www.luogu.com.cn/problem/P5711?contestId=25166