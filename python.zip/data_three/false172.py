#ZeroDivisionError
var1 = 60
var2 = 3 / (var1 >> 6) #ZeroDivisionError
