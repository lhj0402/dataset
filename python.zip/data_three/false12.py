# TypeError
var1 = 99
var2 = '33'
for var in range(5):
    var1 *= var
    print(var1/var2) # TypeError