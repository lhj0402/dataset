#IndexError

list = ['Google', 'Runoob', "Zhihu", "Taobao", "Wiki"]

print("list[6]: ", list[6])#IndexError
