# TypeError
set1 = {1,2,3,4,5}
for var in range(0,len(set1)):
    if var%2 == 0:
        print(set[var])# TypeError