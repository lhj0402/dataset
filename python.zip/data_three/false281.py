#IndexError
import pandas as pd
df = pd.DataFrame(["hdfs://hive/user/prod.db","hdfs:","hdfs://hive/user/test.db"], columns=['location'])

for rw in df.iterrows():
  
        print(rw[1]['location'].split('/')[-1].split('.')[0],rw[1]['location'].split('/')[-1].split('.')[1])#IndexError
        pass