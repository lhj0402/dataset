#ZeroDivisionError
var1 = 180
var2 = 75
var3 = var1 & var2
print(6 / var3) #ZeroDivisionError
