#ZeroDivisionError
var1,var2=map(int,input().split())
var3,var4=1,2
while var2>0:
    if var2%2==1:
        var3=var3*var4%0#ZeroDivisionError
    var4=var4*var4%1000000007
    var2>>=1
var5=(var1+1)*var3%1000000007
var5=(var5-1+1000000007)%1000000007
print(var5)
#https://www.luogu.com.cn/problem/P6195?contestId=27326