# TypeError
var1 = 'a'
var2 = 3
var3 = var1 + var2  # TypeError
print(var3)