var1 = 21
var2 = 10
var3 = var1 + var2
print("var3 的值为：", var3)
