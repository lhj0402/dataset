# IndexError
list1 = [0, 1, 2, 3]
var1 = list1[0]
print(var1)
var2 = list1[1]
print(var2)
var3 = list1[2]
print(var3)
var4 = list1[3]
print(var4)
var5 = list1[4]  # IndexError
print(var5)