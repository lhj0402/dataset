
#!/usr/bin/python
# -*- coding: UTF-8 -*-
#TypeError
a = "acegikm"
b = 5
# 连接字符串
c = a + b#TypeError
print(c)

