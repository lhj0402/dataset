var1 = 10
var2 = 212
print(var1 - var2)
