var1 = 230
var2 = 23101
print(var1 * var2)
