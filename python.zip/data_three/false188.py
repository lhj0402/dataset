#ZeroDivisionError
list = [1, 3, 1, 3, 2, 4, 2]
list.insert(2, 3)
var1 = list.index(2) - 5
print(5 / var1) #ZeroDivisionError
