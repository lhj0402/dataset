#!/usr/bin/python
# -*- coding: UTF-8 -*-
#IndexError
#list  
#新建列表  
testList=[10086,'中国移动',[1,2,4,5]]  
  
#访问列表长度  
print(len(testList))
#到列表结尾  
print(testList[3])  #IndexError
