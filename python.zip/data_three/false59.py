# IndexError
tup1 = 1, 2, 3, 4, 5
list1 = [1, 2, 3, 4, 5]
for var1 in list1:
    var2 = tup1[var1]  # IndexError
    print(var2)