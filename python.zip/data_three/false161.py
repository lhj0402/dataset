#IndexError
list = ['a', 'b']
var1 = 1
while var1 <= 3:
    list.pop() #IndexError
    var1 += 1
