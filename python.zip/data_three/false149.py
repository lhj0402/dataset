# IndexError
var1 = "hello"
print(var1[-7])  # IndexError
