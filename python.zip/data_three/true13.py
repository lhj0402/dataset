# IndexError
list1 = list(range(5))
list1.reverse()
var1 = len(list1)
var = 0
while var < len(list1):
    print(list1[var])
    var += 1