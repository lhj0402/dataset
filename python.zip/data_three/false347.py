#TypeError
list1 = [1,2,3,4,5]
list2 = [1,2,3,4,5]
list3 = list1 * list2   #TypeError
print(list3)