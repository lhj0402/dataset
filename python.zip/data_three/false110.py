# TypeError
dict = {}
dict['one'] = "This is one"
dict[2] = "This is two"
dict[2] = dict['one'] + 1  # TypeError
