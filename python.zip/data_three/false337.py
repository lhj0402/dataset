#IndexError
list1 = [1,1,6,3,0]
list2 = [0]*5
for var1 in range(len(list1)):
    list2[var1] = list1[var1+1]-list1[var1]   #IndexError
print(list2)