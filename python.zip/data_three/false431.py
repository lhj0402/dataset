#ZeroDivisionError
list1=list(input().split())
var1=0
for var2 in list1:
    var3=1/var1#ZeroDivisionError
    var1+=len(var2)
print(var1)
#https://www.luogu.com.cn/problem/P5015?contestId=12956