#  ZeroDivisionError
list1 = [0, 1, 2, 3, 4, 5]
for var1 in list1:
    var2 = 1 / var1  # ZeroDivisionError
    print(var2)