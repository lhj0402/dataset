# TypeError
var1 = complex(real=1, imag=9)
list1 = [1, 2]
print(var1 - list1)  # TypeError
