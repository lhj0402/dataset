# ZeroDivisionError
var1 = 2021
var2 = 1
var3 = 1 - (var1 & var2)
print(var1/var3)  # ZeroDivisionError