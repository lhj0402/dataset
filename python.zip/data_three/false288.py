#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
var1="hello"
print(var1 * '*')

