# TypeError
var1 = '-123456'
var2 = 123456
var3 = abs(var1)  # TypeError
var4 = var1 + var3
print(var4)