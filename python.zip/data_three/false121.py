# ZeroDivisionError
var1 = 1
var2 = 13
var3 = (var1 & var2) - 1
var4 = var2 / var3  # ZeroDivisionError
