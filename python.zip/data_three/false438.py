#IndexError
var1=int(input())
for var2 in range(1,var1+1):
    var3=int(input())
    var4=0
    if var3==1 :
        var4=0
    elif var3%2==1 :
        var4=var3*(var3-1)//2
    else:
        var4=var3*(var3-2)//2+1
    print('xue_jie_hao_piao_liang!')
    list1=[]
    list1.append(1)
    list1.append(2)
    list1.pop()
    list1.pop()
    list1.pop()#IndexError
    list1.append(4)
    list1.append(8)
    list1.pop()
    list1.append(16)