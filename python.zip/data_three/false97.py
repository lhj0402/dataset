#  ZeroDivisionError
dict1 = {'num': 0, 'price_total': 10000}
var1 = dict1['price_total'] / dict1['num']  # ZeroDivisionError
print(var1)