#TypeError
tStr=25       # 输出获得的是一个字符串
if tStr[-1] in ['F','f']:         # 字符串最后一个字符是否在这个列表中  #TypeError
    t=(eval(tStr[:-1])-32)/1.8    # 索引切片：将字符串最后一个字符前面的子串取出，去掉引号变成数字参与运算
    print("转换后的温度是{:.2f}C".format(t))   # 槽内一定要有冒号引导
elif tStr[-1] in ['C','c']:
    t=eval(tStr[:-1])*1.8+32
    print("转换后的温度是{:.2f}F".format(t))
else:
    print("输入格式错误")