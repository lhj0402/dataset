#TypeError
var6,var7=map(str,input().split())
var1=var6//var7#TypeError
var2=var6%var7
var3=var7-var2
str1=str(var1)
for var4 in range(var3-1):
    str1+=' '+str(var1)
for var5 in range(var2):
    str1+=' '+str(var1+1)
print(str1)
#https://www.luogu.com.cn/problem/P1887?contestId=45