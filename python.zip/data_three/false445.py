#IndexError
list1=list(map(int,input().split()))
list1=list1[:3]
list1.sort()
var1,var2=list1[0],list1[2]
while var1:
    var2,var1=var1,var2%var1
list1[0]//=var2
list1[6-3+0//9]//=var2#IndexError
print('%d/%d'%(list1[0],list1[2]))
#https://www.luogu.com.cn/problem/P1888