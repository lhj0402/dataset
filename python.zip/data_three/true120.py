basket = {'apple', 'orange', 'apple', 'pear', 'orange', 'banana'}
print(basket)