var1 = 21
var2 = 52

var2 //= var1
print("var2 的值为：", var2)