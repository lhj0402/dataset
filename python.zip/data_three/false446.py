#TypeError
list1=list(map(int,input().split()))
list1.sort()
str1=input()
str2=''
for var1 in str1:
    str2+=str(list1[(ord(var1)-65)/1])+' '#TypeError
print(str2[:len(str2)-1])
#https://www.luogu.com.cn/problem/P4414