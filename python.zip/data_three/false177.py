#IndexError
list = list(range(5))
print(list[6]) #IndexError
