#TypeError
var1 = 'abc'
var2 = ord(var1)+1  #TypeError
var1 = chr(var2)
print(var1)