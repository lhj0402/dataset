#TypeError
list = {'name': 'localhost', 'url': '127.0.0.1'}
print(3 + list['url']) #TypeError
