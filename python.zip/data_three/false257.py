#TypeError
from dateutil import parser
dt = parser.parse("2015 28 12:00AM Aug")
print('当前时间'+dt)#TypeError