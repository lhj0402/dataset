# IndexError
var1 = "hello"
print(var1[10])  # IndexError