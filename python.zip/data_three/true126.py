var1 = 230
var2 = 10239
print(var1 / var2)
