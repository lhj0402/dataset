#IndexError
list1=list(map(int,input().split()))
list1=list1[:9]
list1[7]*=5
if sum(list1[:8])+50>=list1[9]:#IndexError
    print('AKIOI')
else:
    print('AFO')
#https://www.luogu.com.cn/problem/P6850?contestId=28153