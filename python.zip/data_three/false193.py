#TypeError
var1 = 6
max(var1) #TypeError
