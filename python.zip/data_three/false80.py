# TypeError
tuple1 = 1, 2, 3
set1 = set(tuple1)
var1 = set1[1]  # TypeError
print(var1)