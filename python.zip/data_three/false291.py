#ZeroDivisionError
list1=[2,6,8,0,4]
var1=100
for i in list1[:]:
    var1/=i  #ZeroDivisionError