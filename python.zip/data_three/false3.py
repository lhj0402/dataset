# TypeError
str1 = 'hello,2021'
if str1.endswith(2021): # TypeError
    print('endwith2021')