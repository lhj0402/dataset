var1 = 'this is a str '
var2 = '123'
var3 = str(456)
print(var1+var2)
print(var1+var2+var3)