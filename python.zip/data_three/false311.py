#TypeError
var1 = 'I have a pet cat.'
var1[13] = 'r'  #TypeError
print(var1)