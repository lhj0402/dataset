# IndexError
list1 = range(5)
var1 = len(list1)
var = 0
while var >= -len(list1):
    var -= 1
    print(list1[var])# IndexError