#IndexError
str1=input()
print(str1.upper())
str2='xue_zhang_hao_shuai_!'
print(str2[110])#IndexError
#https://www.luogu.com.cn/problem/P5733?contestId=24871