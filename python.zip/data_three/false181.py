#TypeError
import time
var1 = time.localtime(time.time())
print(var1 + 3j) #TypeError
