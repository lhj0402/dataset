# IndexError
list1 = ['lcw', 786, 2.23, 'john', 70.2]
list1[-98] = 100  # IndexError