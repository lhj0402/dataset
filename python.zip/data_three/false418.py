#IndexError
var1=int(input())
list1=list(map(int,input().split()))
list2=[]
list2.pop()#IndexError
for var2 in list1:
    if var2<=1:
        continue
    var4=True
    for var3 in range(2,var2):
        if var2%var3==0:
            var4=False
            break
    if var4:
        list2.append(var2)
var5=""
for var2 in list2:
    var5=var5+str(var2)+" "
print(var5[:len(var5)-1])
#https://www.luogu.com.cn/problem/P5736?contestId=26244