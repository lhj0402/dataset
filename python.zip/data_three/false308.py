#TypeError
var1 = 'abc'
var2 = ord(var1)    #TypeError
print(var2)