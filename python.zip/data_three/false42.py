# ZeroDivisionError
import numpy as np
array1 = np.zeros((5))
array2 = np.ones((5))
var1 = len(array1)
var2 = sum(array1*array2)
print(var1/var2) # ZeroDivisionError