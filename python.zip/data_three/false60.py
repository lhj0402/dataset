# IndexError
dict1 = {'age': 10, 'name': 'jsw'}
var1 = dict1['age']
list1 = [var1 for var1 in range(10)]
print(list1)
var3 = list1[var1]  # IndexError
print(var3)