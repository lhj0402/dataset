#  ZeroDivisionError
list1 = [1, 2, 3]
list1.clear()
print(10 / len(list1))  # ZeroDivisionError
