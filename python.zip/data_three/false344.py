#ZeroDivisionError
list1 = [0]*5
var1 = 0
var2 = 0
for var3 in range(len(list1)):
    if list1[var2] == 0:
     del list1[var2]
    else:
     var1=var1+list1[var2]
     var2 = var2+1
var4 = len(list1)
print(var1/var4)    #ZeroDivisionError