#TypeError
var1=input()
if var1<=0:#TypeError
    print(0)
else:
    var1=int(var1)
    print(var1*2-1)
#https://www.luogu.com.cn/problem/P6581?contestId=29966