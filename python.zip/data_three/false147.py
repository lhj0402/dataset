# TypeError
var1 = 1
list1 = [1, 2]
print(var1 + list1)  # TypeError
