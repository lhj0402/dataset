#IndexError
list1 = [1,2,3,4,5]
for var1 in range(6):     #IndexError
    print(list1[var1])