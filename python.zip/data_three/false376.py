# TypeError
var1 = set('lcadfswwwwww')  # TypeError
print(var1[4])
