#TypeError
str1=input()
var4,str2=1,"#"
while var4<=3:
    index1=str1[var4*2-1]
    index2=str1[var4*2]
    var1=0
    if index1<='9' and index1>='0':
        var1+=(index1-'0')*16#TypeError
    else:
        var1+=(ord(index1)-ord('A')+10)*16
    if index2<='9' and index2>='0':
        var1+=(ord(index2)-ord('0'))
    else:
        var1+=(ord(index2)-ord('A')+10)
    var1=255-var1
    var2=var1//16
    var3=var1%16
    if var2<=9 and var2>=0:
        str2+=chr(ord('0')+var2)
    else:
        var2-=10
        str2+=chr(ord('A')+var2)
    if var3<=9 and var3>=0:
        str2+=chr(ord('0')+var3)
    else:
        var3-=10
        str2+=chr(ord('A')+var3)
    var4+=1;
print(str2)