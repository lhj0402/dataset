#IndexError
list1 = [1,2,3,4,5]
for var1 in range(len(list1)):
    print(list1)
    print(var1)
    list1.pop()
    print(list1[0])     #IndexError