# TypeError
list1 = [1,2,3]
list2 = [4,5,6]
print(list1+list2)
str1 = 'upc'
print(list1+str1)# TypeError