#TypeError
var1 = 'abc'
var2 = 1
var3 = var1 * var2
var4 = var3 / var1  #TypeError
print(var4)