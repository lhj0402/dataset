#  ZeroDivisionError
list1 = [-1, 0, 1, 2, 3, 4]
list2 =[]
for var1 in list1:
    var2 = var1 * 10
    list2.append(var2)
print(list2)
for var3 in list2:
    var4 = 10 / var3  # ZeroDivisionError
    print(var4)