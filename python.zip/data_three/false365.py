# TypeError
t = (1,2,3)
dic1 = {t:t}
print(dic1)
list1 = [1,2,3]
dic2 = {list1:list1} # TypeError
print(dic2)