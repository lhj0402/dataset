#TypeError
var = 'helloworld'
print(var[max(var)]) #TypeError
