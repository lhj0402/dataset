# IndexError
list1 = []
var1 = 0
while var1 != 0:
    list1.append(var1 + 1)
var2 = list1[0]  # IndexError
print(var2)