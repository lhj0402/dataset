# IndexError
list1 = ['a', 'b', 'c', 'd', 'e']
for var1 in range(len(list1)):
    if list1[var1] == 'b' or list1[var1] == 'c':  # IndexError
        list1.remove(list1[var1])
print(list1)