# TypeError
list1 = [1, 2, 3]
var1 = 20
var2 = var1 / list1  # TypeError
print(var2)