# IndexError
str1 = ' i love study python '
var1 = len(str1)
str2 = str1.strip()
print(var1)
for var2 in range(var1):
    var3 = str2[var2]  # IndexError
    print(var3)
