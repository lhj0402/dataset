# ZeroDivisionError
list1 = ['Google', 'baidu', 1997, 2000]
print(20 / list1.count('2'))  # ZeroDivisionError