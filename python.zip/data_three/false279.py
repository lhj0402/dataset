#!/usr/bin/python
# -*- coding: UTF-8 -*-
#TypeError
sStr1 = 'abcdefg'
sStr2 = 'cde'
print(sStr1+"  "+sStr2+" "+sStr1.find(sStr2)) #TypeError

