# TypeError
str1 = 'jsw'
var1 = 1
var2 = str1 + var1  # TypeError
print(var2)