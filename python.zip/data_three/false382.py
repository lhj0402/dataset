# TypeError
var1 = 2
var2 = 10
var3 = 0

if var1 == var2:
    print("1 - var1 等于 var2")
else:
    print('str' + var3)  # TypeError
