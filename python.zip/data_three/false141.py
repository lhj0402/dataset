# ZeroDivisionError
import numpy as np

list1 = [1, 2, 3, 4]
np1 = np.array(list1)
var1 = int(np1[1] - 2)
print(10 / var1)  # ZeroDivisionError
