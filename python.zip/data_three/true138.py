var1 = 60
var2 = 13

var3 = var1 & var2
print("var3 的值为：", var3)
