#ZeroDivisionError
list1 = [1,2,6,3,0]
for var1 in range(len(list1)):
    list1[var1] = 1/list1[var1] #ZeroDivisionError
var2 = max(list1)
print(var2)