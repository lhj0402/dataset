dict = {}
dict['one'] = "This is one"
dict[2] = "This is two"
print(dict['one'])
