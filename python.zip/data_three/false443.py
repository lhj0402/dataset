#IndexError
var1=int(input())
var2=5*var1
var3=11+3*var1
if var2<var3:
    print('Local')
else:
    print('Luogu')
list1=[999]
list1.pop()
list1.pop()#IndexError
#https://www.luogu.com.cn/problem/P5713