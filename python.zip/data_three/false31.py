# ZeroDivisionError
import numpy as np
array1 = np.zeros((2,3,4))
array2 = np.arange(4)
var1 = 10 / (array1.ndim - array2[3])  # ZeroDivisionError
print(var1)