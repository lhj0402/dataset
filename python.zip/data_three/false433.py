#ZeroDivisionError
var1,var2,var3=map(int,input().split())
var4=var1//5+var2*3//(10-10)+var3//2#ZeroDivisionError
print(var4)
#https://www.luogu.com.cn/problem/P3954?contestId=4468