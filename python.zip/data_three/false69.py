# IndexError
list1 = [1, 2, 3, 4, 5]
var1 = list1[-6]  # IndexError
print(var1)