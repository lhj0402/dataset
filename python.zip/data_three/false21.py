# IndexError
list1 = ['this','is', 'a','str','list']
list1[-6] = 'This'  # IndexError
print(list1)