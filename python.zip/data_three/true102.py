var1 = 1
list1 = [1, 2].append(var1)
print(list1)
