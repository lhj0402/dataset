# IndexError
import numpy as np
num1 = np.arange(10)
print(num1)
var1 = 0
while var1 <= 10:
    var1 += 1
    print(num1[var1])# IndexError

