#TypeError
var1,var2=input().split()
var3=var1*var2#TypeError
print(var3)
#https://www.luogu.com.cn/problem/P5703?contestId=24871