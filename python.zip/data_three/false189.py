#IndexError
list = [1, 2, 3, 4, 5, 6]
list.clear()
print(list[1]) #IndexError
