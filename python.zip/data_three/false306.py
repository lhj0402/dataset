#TypeError
var1 = 'a'
var2 = var1+1  #TypeError
var1 = chr(var2)
print(var1)