#TypeError
var1=int(input())
var2=input()
print(var1-var2)#TypeError
#https://www.luogu.com.cn/problem/P2142