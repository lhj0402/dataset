# ZeroDivisonError

list = ['Google', 'Runoob', 1997, 2000]

print("第三个元素为 : ", list[2])
list[2] = 2001/0  # ZeroDivisonError
print("更新后的第三个元素为 : ", list[2])