#TypeError
var1 = 'abc'
var2 = 'cba'
print(var1)
print(var2)
var3 = var1 * var2  #TypeError
print(var3)