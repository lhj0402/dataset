# TypeError
var1 = 123
var2 = '122'
if var1>var2: # TypeError
    print('var1>var2')
else:
    print('var1 less than or equal to var2')