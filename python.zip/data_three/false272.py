#!/usr/bin/python3
 #IndexError
def output(s,l):
    if l==0:
       return
    print (s[l]) #IndexError
    output(s,l-1)
 
s = "mahdjkold"
l = len(s)
output(s,l)
