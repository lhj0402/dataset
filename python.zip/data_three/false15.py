# IndexError
list1 = ['welcome', 'to', 'upc!']
list1.clear()
list1.pop()  # IndexError