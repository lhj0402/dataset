#ZeroDivisionError
var1,var2,var3=map(int,input().split())
var3=min(var3,var1*var2)
var4=var2=0
if var2>=0:
    var4=(var3-1)//var2+1#ZeroDivisionError
else:
    var4=var1
print(var1-var4)
#https://www.luogu.com.cn/problem/P5709?contestId=24871