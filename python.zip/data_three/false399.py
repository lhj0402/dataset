# IndexError
list1 = ["China", "Canada"]
print(list1[3]) # IndexError