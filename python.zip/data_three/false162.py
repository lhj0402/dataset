#ZeroDivisionError
var1 = 1 + 2j
var2 = 2 / var1
var3 = var2 - 0.4 + 0.8j
print(3 / (var3)) #ZeroDivisionError
