#ZeroDivisionError
var1 = 32
var2 = 3 
var1 %= var2
var1 //= var2
var2 / var1 #ZeroDivisionError
