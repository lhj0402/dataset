#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #ZeroDivisionError
if __name__ == '__main__':
    sum = 4
    s = 4
    m=3
    for j in range(2,9):
        print(sum)
        if j <= 2:
            s *= 7
        else:
            s /= m #ZeroDivisionError
            m=m-1
        sum += s
    print('sum = %d' % sum)


