#TypeError
list = [1, 2, 3, 4]
var = list.count();
print(var) #TypeError
