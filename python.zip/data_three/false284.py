#!/usr/bin/python
# -*- coding: UTF-8 -*-
#TypeError
score = "85"
if score >= 90:  #TypeError
    grade = 'A'
elif score >= 60:
    grade = 'B'
else:
    grade = 'C'

print('%d belongs to %s' % (score, grade))