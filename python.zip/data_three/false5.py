# TypeError
set1 = {'element1', 'element2', 'element3', 'element4', 'element5'}
set1.add('element6')
print(set1)
set1.pop('element6')  # TypeError
print(set1)
