# TypeError
str1 = ' 0 1 2 3'
list1 = str1.split(' ')
list2 = ['lcw', 'jsw', 'sh', 'lyc']
for var1 in list1:
    var2 = ord(var1)  # TypeError
    var3 = list2[var2]