#TypeError
var1=input()
str2=input()
list1,var2=[],1
for var3 in range(var1):#TypeError
    list1.append(var3+1)
while True:
    str1=''
    for var3 in list1:
        str1+=str(var3)
    if str1==str2:
        break
    var4,var5=-1,0
    for var4 in range(len(list1)-2,-1,-1):
        if list1[var4]<list1[var4+1]:
            break
    for var5 in range(len(list1)-1,-1,-1):
        if list1[var5]>list1[var4]:
            break
    if var4>=0:
        var7=list1[var5]
        list1[var5]=list1[var4]
        list1[var4]=var7
    list2=list1[var4+1:]
    list2.reverse()
    for var6 in range(1,len(list2)+1):
        list1[var4+var6]=list2[var6-1]
    var2+=1
print(var2)
#https://www.luogu.com.cn/problem/P2524?contestId=221