# TypeError
var1 = "HellO"
var1 = var1 / 9  # TypeError
print(var1)
