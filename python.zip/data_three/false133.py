# TypeError
var1 = bool(0)
var2 = int(var1 + '1')  # TypeError
