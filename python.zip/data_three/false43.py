# ZeroDivisionError
var1 = False
var2 = 2021
print(var2/int(var1))# ZeroDivisionError