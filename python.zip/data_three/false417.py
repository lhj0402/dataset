#TypeError
var1=int(input())
list1=list(map(int,input().split()))
print(max(list1)-list1)#TypeError
#https://www.luogu.com.cn/problem/P5724?contestId=26244