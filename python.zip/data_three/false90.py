# TypeError
str1 = ''
var1 = 100
while var1 != 0:
    str1 += var1  # TypeError
    var1 -= 1
print(str1)