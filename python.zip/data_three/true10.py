list1 = ['p', 'c']
list2 = ['u']
list2 += list1
for var in list2:
    print(var)