# ZeroDivisonError

list = [99,88,77,66,55,44]

print(list[-5]/0)# ZeroDivisonError
