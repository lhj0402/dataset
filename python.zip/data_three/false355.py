# IndexError
list1 = []
list1.pop()    # IndexError
list1.append(1)
print(list1)