#IndexError
var1,var2,var3=map(int,input().split())
sum1=0
if abs(var1-var2)>=var3:
    sum1=min(var1,var2)+var3
else:
    sum1=max(var1,var2)
    sum1+=(var3-abs(var1-var2))//2
var4=1
while var4>=1:
    if var4<=sum1:
        sum1-=var4
    else:
        break
    var4+=1
print(var4-1)
list1=[]
list1.append(5618)
list1[1]=177#IndexError
#https://www.luogu.com.cn/problem/P6784?contestId=33190