#IndexError
list1 = [0]*5
var1 = 0
for var2 in range(len(list1)):
    if list1[var2] == 0:    #IndexError
     del list1[var2]
    else:
     var1=var1+list1[var2]
     var2 = var2+1
