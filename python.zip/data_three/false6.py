# TypeError
list1 = [1,2,3]
set1 = {4,5,6}
print(list1+set1)# TypeError