# ZeroDivisionError
for var1 in range(5):
    var2 = 1 / var1  # ZeroDivisionError
    print(var2)
