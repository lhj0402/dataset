#IndexError
list1 = [1,2,3,4,5]
for var1 in range(len(list1)):
    del list1[var1]     #IndexError
    print(list1)