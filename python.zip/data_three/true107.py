tuple1 = ('lcw', 786, 2, 70.2)
print(tuple1 * 3)
