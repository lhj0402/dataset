#TypeError
var1,var2=map(int,input().split())
var4=0
for var3 in range(1,var1+1):
    str1=str(var3)
    var4+=str1.count(var2)#TypeError
print(var4)
#https://www.luogu.com.cn/problem/P1980