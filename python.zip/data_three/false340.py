#ZeroDivisionError
list1 = [1,1,6,3,0]
var1 = 0
for var2 in range(len(list1)):
    var1 = var1 + list1[var2]
    list1[var2] = var1/var2 #ZeroDivisionError
print(list1)