#  ZeroDivisionError
str1 = '0123456789'
list1 = list(str1)
var1 = 100
for var2 in reversed(list1):
    if int(var2) % 2 == 0:
        var1 = int(var2)
var3 = 123456789 / var1  # ZeroDivisionError
print(var3)