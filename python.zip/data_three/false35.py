# ZeroDivisionError
str1 = 'division by zero'
var1 = str1.count('d')
var2 = str1.count('i')
var3 = str1.count('v')
print(var2/(var3-var1))  # ZeroDivisionError