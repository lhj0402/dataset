# IndexError
tup1 = 'this','is','a','tuple'
print(tup1[4])  # IndexError