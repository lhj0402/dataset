# TypeError
import numpy as np

numpy1 = np.arange(10)
list1 = []
for i in range(0, 3):
    list.insert(int(numpy1[i]))  # TypeError
for i in range(0, 3):
    print(10 / list1.pop())
