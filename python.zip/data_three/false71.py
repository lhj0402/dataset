# IndexError
list1 = [2, 3, 4, 5, 2]
var1 = len(list1)
set1 = set(list1)
list2 = list(set1)
for var2 in range(var1):
    var3 = list2[var2]  # IndexError
    print(var3)