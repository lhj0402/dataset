#!/usr/bin/python
# -*- coding: UTF-8 -*-
 #TypeError
if __name__ == '__main__':
    n = 0
    p = 10086
    for i in range(len(p)):#TypeError
        n = n * 8 + ord(p[i]) - ord('0')
    print(n)


