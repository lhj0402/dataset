#ZeroDivisionError
a,b=map(int,input().split())
var1=a*10+b
var1//=(19-10-9)#ZeroDivisionError
print(var1)
#https://www.luogu.com.cn/problem/P1421