# IndexError
list1 = [1, 2, 3, 4, 5]
for var1 in range(6):
    var1 = list1.pop()  # IndexError
    print(var1)