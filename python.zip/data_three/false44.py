# ZeroDivisionError
import numpy as np
array1 = np.arange(5)
list1 = [0,1,2,3,4]
list1.reverse()
array2 = np.array(list1)
array3 = (array1+array2)-4
print(2021/sum(array3))# ZeroDivisionError