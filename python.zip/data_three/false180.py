#TypeError
import re
var1 = 'www.baidu.com'
var2 = 'www'
var3 = 'baidu'
var4 = int(re.match(var2, var1)) / int(re.match(var3, var1)) #TypeError
