# ZeroDivisonError
print(5/0)  # ZeroDivisonError