# TypeError
set1 = {1, 2, 3}
list1 = [[23, 4], [21, 3.56]]
print(set1 + list1)  # TypeError
