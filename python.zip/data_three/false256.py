#TypeError
if __name__ == '__main__':
    import time
    start = time.clock()
    for i in range(10000):
        print(i)
    end = time.clock()
    print('different is %c' % (end - start)) #TypeError
