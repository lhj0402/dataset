set1 = set("hwoolfw")
set2 = set("fqjooosdfdqwllcww")
print(set1 - set2)
