
#!/usr/bin/python
# -*- coding: UTF-8 -*-
#TypeError
delimiter = ','
mylist = [8, 'Russia', 'India', 'China']
print(delimiter.join(mylist))#TypeError
