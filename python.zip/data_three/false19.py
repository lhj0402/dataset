# IndexError
list1 = [1, 2, 3, 4]
list2 = list1[-4:-1:3]
print(list2[1]) # IndexError
