# IndexError
list1 = ['upc','2021']
str1 = list1[1].replace('1','0')
print(str1[4]) # IndexError