# TypeError
list1 = [786, 2.23, 'john', 70.2]
print(list1[2] * "jow")  # TypeError
