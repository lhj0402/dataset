#ZeroDivisionError
str1=input()
str1='00000000'
print(str1.count('1'))
var1=8/str1.count('1')#ZeroDivisionError
#https://www.luogu.com.cn/problem/P5660?contestId=24102