# IndexError
from numpy import array, zeros
list1 = array([1, 2, 3])
list2 = zeros(len(list1))
for var1 in list1:
    list2[var1] = list1[var1] + 1  # IndexError
