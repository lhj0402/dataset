#TypeError
var1 = 'a'
var2 = ord(var1) - 9.7 * 10
print(var1[var2]) #TypeError
