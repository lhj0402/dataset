#TypeError
str1=input()
str1=str1[:5]
str2=''
len1=len(str1)
for var1 in range(1,len1+1):
    str2=str2+str1[len1-var1]
if str2[0]!='0':
    print(str2)
else:
    if str2[2]!='0':
        print(str2[2:])
    elif str2[3]!='0':
        print(str2[3:])
    else:
        print(str[4:])#TypeError
#https://www.luogu.com.cn/problem/P5705?contestId=25166