#TypeError
var='hello'
print(var + 3) #TypeError
print(var)
