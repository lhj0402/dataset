#IndexError
list = [1, 2, 3, 4, 6]
var1 = var2 = 0
while var1 < max(list):
    var2 += list[var1] #IndexError
    var1 += 1
