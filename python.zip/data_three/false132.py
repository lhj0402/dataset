# IndexError
list1 = range(0, 0)
print(list1[0])  # IndexError
