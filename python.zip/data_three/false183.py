#ZeroDivisionError
import time
var1 = time.localtime(time.time()).tm_isdst
var2 = time.localtime(time.time()).tm_mon
print(var2 / var1) #ZeroDivisionError
