# TypeError
print(1+'1') # TypeError