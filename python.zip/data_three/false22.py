# IndexError
list1 = [1,2,3,4]
list1.append([5,6,7])
var1 = 0
while (var1 < 7):
    var1 += 1
    print(list1[var1])  # IndexError
