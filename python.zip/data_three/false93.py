# TypeError
dict1 = {'age': 20, 'salary': 4000}
dict2 = {'age': 22, 'salary': 5000}
var1 = dict2 - dict1  # TypeError
print(var1)