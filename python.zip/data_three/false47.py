# TypeError
list1 = {1,2,3,4,'5',6}
var1 = 0
for temp in list1:
    var1 += temp # TypeError
print(var1)