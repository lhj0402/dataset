#TypeError
var1,var2=map(int,input().split())
var2-=(7-var1+1)
var3=0
if var1<=5:
    var3+=(5-var1+1)*250
var3+=(var2//7)*250*5
var4=var2%7
var4=min(var4,'5')#TypeError
var3+=var4*250
print(var3)
#https://www.luogu.com.cn/problem/P1424