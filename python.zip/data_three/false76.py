# TypeError
list1 = [2, 3, 4, 5, 2]
var1 = len(list1)
set1 = set(list1)
for var2 in range(var1):
    var3 = set1[var2]  # TypeError
    print(var3)