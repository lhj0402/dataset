#TypeError
var1 = 98
var2 = chr(var1)+6  #TypeError
print(var2)