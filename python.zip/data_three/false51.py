# ZeroDivisionError
var1 = 5 / 0  # ZeroDivisionError
print(var1)
