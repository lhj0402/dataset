#IndexError
list1 = [1,2,3,4,5]
list1[5] = 6    #IndexError
print(list1)