#TypeError
list1 = ('hello', 24)
list2 = list(list1)
print(list1 + list2) #TypeError
