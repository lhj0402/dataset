# IndexError
list1 = ['welcome', 'to', 2021,'!']
for i in range(5):
    list1.pop()  # IndexError