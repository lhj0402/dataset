#IndexError
var = 'helloworld'
print(var[ord(max(var))]) #IndexError
