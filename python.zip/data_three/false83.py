# TypeError
str1 = 'i love it'
str1[0] = 'u'  # TypeError
print(str1)