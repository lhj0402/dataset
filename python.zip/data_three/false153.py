#IndexError
var1 = "helloworld"
print(var1[-11]) #IndexError
