# IndexError
import random
list1 = [x for x in range(0, 11)]
random.shuffle(list1)
list2 = [x for x in range(0, 10)]
random.shuffle(list2)
for var in range(len(list1)):
    print(list1[var]+list2[var])# IndexError