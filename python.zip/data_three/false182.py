#TypeError
import time
var1 = time[8]
print(var1) #TypeError
