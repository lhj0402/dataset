# IndexError
str1 = 'pycharm'
list1 = list(str1)
print(list1)
del list1[-8]  # IndexError