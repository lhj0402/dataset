#IndexError
list1 = ['a','b','c']
print(list1[3]) #IndexError