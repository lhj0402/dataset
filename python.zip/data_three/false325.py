#IndexError
list1 = [1,2,3,4,5]
var1 = len(list1)
list1.pop(-1)
print(list1[var1-1])  #IndexError