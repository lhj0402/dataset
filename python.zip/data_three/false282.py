#ZeroDivisionError
var1=100
var2=65
for i in range(20):
    
    var3=var1/var2 #ZeroDivisionError
    var1=var2
    var2=var3
    print(var3)