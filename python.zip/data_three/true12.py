var1 = 99
var2 = '33'
if var2.isdigit():
    var2 = int(var2)
for var in range(5):
    var1 += var+1
    print(var1/var2)