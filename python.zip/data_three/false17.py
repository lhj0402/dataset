# IndexError
list1 = [1,2,3,4,5]
var1 = len(list1)+1
list1[-var1] = 0 # IndexError