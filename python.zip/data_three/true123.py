var1 = 1
print(var1 + 1)
