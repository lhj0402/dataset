# TypeError
var1 = '12345'
var2 = 1234567
var3 = min(len(var1),len(var2))# TypeError
for var in range(var3):
    print(var1[var])
    print(var2[var])
