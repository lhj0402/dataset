#TypeError
list = [1, 2, 3]
var1 = 1j
print(list[var1 * var1]) #TypeError
