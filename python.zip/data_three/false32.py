# ZeroDivisionError
list1 = [1, 2, 3, 4, 5, 6]
list1.clear()
var1 = 10 / list1.count(1)  # ZeroDivisionError