# TypeError
tuple = (2.23, 'john', 70.2)
tuple[2] = 1000  # TypeError
