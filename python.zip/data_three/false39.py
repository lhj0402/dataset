# ZeroDivisionError
import math
var1 = math.pi
var2 = math.floor(var1)
list1 = range(3)
print(2021/(sum(list1)-var2)) # ZeroDivisionError