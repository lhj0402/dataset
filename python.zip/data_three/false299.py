#TypeError
if __name__ == '__main__':
    import time
    print(2020+time.asctime(time.localtime(time.time()))) #TypeError
