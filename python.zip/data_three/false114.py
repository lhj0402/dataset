# TypeError
var1 = complex(real=1, imag=9)
print(var1 > 2)  # TypeError
