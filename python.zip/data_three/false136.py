# TypeError
set1 = {1, 2, 3.5}
set1.union([12, 37])
i = 10
while (i > 3):
    i -= 1
    print(set1[i])  # TypeError
