var1 = 1209
var2 = 'fwojfw'
if var2 == 'wjof':
    print(var1)
else:
    print("fowjf")
