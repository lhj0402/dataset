#IndexError
list = ['a', 'b']
var1 = 1
while var1 <= 2:
    list.pop()
    var1 += 1
print(list[0]) #IndexError
