#ZeroDivisionError
var1 = 255 
var2 = ~var1 
var3 = var2 + (1 << 8) 
var4 = 1 % var3 #ZeroDivisionError
