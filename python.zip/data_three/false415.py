#TypeError
var1=int(input())
#list1=list(map(int,input().split()))
list1=list(int,input().split())#TypeError
print(min(list1))
#https://www.luogu.com.cn/problem/P5718?contestId=26244