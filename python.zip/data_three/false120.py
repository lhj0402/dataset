# TypeError
var1 = 2
var1 += 'st'
print(var1)  # TypeError
