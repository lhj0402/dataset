# IndexError
list1 = [[0, 1], [2, 3], [4, 5], [6]]
for var1 in list1:
    var2 = var1[1]  # IndexError
    print(var2)
