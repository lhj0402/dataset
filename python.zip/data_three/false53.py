#  ZeroDivisionError
list1 = [var1 for var1 in range(100)]
print(list1)
for var2 in list1:
    if var2 % 2 == 0:
        var3 = 1 / var2  # ZeroDivisionError
        print(var3)