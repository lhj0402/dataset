#TypeError
var1,var2=map(int,input().split())
ans='1'
for var4 in range(var1):
    var3*=10
var3+=var2#TypeError
print(var3)
#https://www.luogu.com.cn/problem/P6745?contestId=30167