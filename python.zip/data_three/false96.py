# TypeError
str1 = 'abc'
list1 = ['a', 'b', 'c']
if str1 > list1:  # TypeError
    print("hello")
