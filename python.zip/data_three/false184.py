#TypeError
var1 = 3.14
var2 = 3
var3 = '3.1415926'
var4 = var1 + var2
print(var3[var4]) #TypeError
