#TypeError
list1 = [1,2,-1,2,3,4]
list2 = abs(list1)  #TypeError
print(list2)