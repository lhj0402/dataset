#TypeError
list = [11, 22, 33]
var1 = 2
var2 = float(var1)
print(list[var2]) #TypeError
