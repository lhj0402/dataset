#IndexError
list1 = [0]*5
var1 = 0
var2 = 0
for var3 in range(len(list1)):
    if list1[var2] == 0:
     list1.pop(1)     #IndexError
    else:
     var1=var1+list1[var2]
     var2 = var2+1