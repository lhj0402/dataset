# TypeError
var1 = set('lcadfswwwwww')
var2 = frozenset(var1)
print(var2[3])  # TypeError
