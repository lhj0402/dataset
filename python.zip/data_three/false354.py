#TypeError
var1 = 'abc'
print(var1)
var2 = -var1    #TypeError
print(var2)