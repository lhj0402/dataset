# TypeError
str1 = 'abcd'
del str1[0]  # TypeError