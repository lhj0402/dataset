#TypeError
var1="hello"+5; #TypeError