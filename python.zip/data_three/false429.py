#IndexError
str1=input()
cnt1=0
chr1=str1[0]
list1=[]
for var1 in range(len(str1)):
    if str1[var1]==chr1:
        cnt1+=1
    else:
        if chr1=='0':
            list1.append(cnt1)
            cnt1=1
            chr1='1'
        else:
            list1.append(-cnt1)
            cnt1=1
            chr1='0'
if chr1=='0':
    list1.append(cnt1)
else:
    list1.append(-cnt1)
for var1 in range(1,len(list1)+1):
    list1[var1]+=list1[var1-1]#IndexError
var2,var3=-1,0
for var1 in range(len(list1)):
    var2=max(var2,list1[var1]-var3)
    var3=min(var3,list1[var1])
print(var2)
#https://www.luogu.com.cn/problem/P5650?contestId=23456