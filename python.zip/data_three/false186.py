#IndexError
list = {'name': 'localhost', 'url': '127.0.0.1'}
print(list['url'][-10]) #IndexError
