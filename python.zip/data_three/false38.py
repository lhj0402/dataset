# ZeroDivisionError
var1 = 10
list1 = [2,0,2,1]
str1 = 'cpu'
if str1 == 'upc':
    var1 = var1 * 2
else:
    var1 = var1 & 0
print(list1[1] / var1)  # ZeroDivisionError