# IndexError
import random
import math
var1 = random.random()
list1 = range(0, 0)
var2 = math.floor(var1)
print(list1[var2])  # IndexError