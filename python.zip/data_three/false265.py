#!/usr/bin/python3
#IndexError
l = [6,159,5,26,98,589,1]
l.sort()
l.clear()
print (l[1]) #IndexError
