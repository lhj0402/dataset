#IndexError
list = [1, 3, 4, 2, 5, 5]
var1 = 1
var2 = 0
while var1 <= 4:
    while var2 <= len(list):
        print(list[var2]) #IndexError
        var2 += var1
    var1 += 1
    var2 = 0
