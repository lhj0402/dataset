#TypeError
var1 = 12
print('I have '+var1+' eggs.')   #TypeError