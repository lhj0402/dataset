#IndexError
var1=int(input())
var2=1
list1=[5,2,0,1,3,1,4]
while var1>1:
    var2+=1
    var1//=2
list1[69]+=512#IndexError
print(var2)
#https://www.luogu.com.cn/problem/P5720