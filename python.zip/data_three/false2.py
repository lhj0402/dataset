# TypeError
list1 = ['u','p','c','c']
del list1[3]
print(list1)
tup1 = 'u','p','c','c'
del tup1[3]# TypeError
print(tup1)
